'use strict';

var React = require('react/addons');


require('styles/Content.scss');

var Content = React.createClass({
  render: function () {
    return (
        <div>
          <p>Content - {this.props.note.content}</p>
        </div>
      );
  }
});

module.exports = Content; 

