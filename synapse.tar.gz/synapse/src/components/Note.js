"use strict";

var React = require('react');
var Router = require('react-router');

var Note = React.createClass({
  mixins: [ Router.State ],
  getInitialState: function(){
    var route = this.getPath();
    var storedNote = (localStorage.getItem(route) || "new note");
    console.log(storedNote);
      return ({
          note: storedNote,
      });
  },
  handleChange: function(event) {
    var route = this.getPath();
    localStorage.setItem(route, event.target.value);
    this.setState({note: event.target.value});
  },
  render: function () {
    var route = this.getPath();
    return (
        <div className="note-container">
          <span>{route}</span>
          <textarea defaultValue={this.state.note} onChange={this.handleChange}></textarea>
        </div>
    );
  }
});

module.exports = Note; 
