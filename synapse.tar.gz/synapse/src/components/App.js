"use strict";
var React = require('react');
var Router = require('react-router');
var Note = require("./Note.js");
var Index = require("./Index.js");
var Settings = require("./Settings.js");
var Synapse = require("./Synapse.js");
var Route = Router.Route;
var Redirect = Router.Redirect;
var RouteHandler = Router.RouteHandler;
var State = Router.State;
var Link = Router.Link;


var App = React.createClass({
  render () {
    return (
      <div>
        <Link to="synapse"><span>synapse</span></Link>
        <RouteHandler  />
      </div>
    );
  }
});



var routes = (
  <Route handler={App}>
    <Route name="index" path="index" handler={Index}/>
    <Route name="settings" path="settings" handler={Settings}/>
    <Route name="synapse" path="synapse" handler={Synapse}/>
    <Redirect from="/" to="index" />
    <Route path=":id" handler={Note}/>
  </Route>
);

Router.run(routes, Router.HashLocation, (Root) => {
  React.render(<Root params={State.params}/>, document.body);
});
