"use strict";

var React = require('react');
var Router = require('react-router');

var Index = React.createClass({
  mixins: [ Router.State ],
  render: function () {
    var name = this.getPath();
    return (
        <div>
          <span>{name}</span>
          https://wireframe.cc/JtMUt7
          this model kicks ass http://jsfiddle.net/jardalu/Z4Xzh/
          <ul>
            <li>notes!</li>
            <li>notes!</li>
            <li>notes!</li>
            <li>notes!</li>
          </ul>
        </div>
    );
  }
});

module.exports = Index; 
