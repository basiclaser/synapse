"use strict";

var React = require('react');
var Router = require('react-router');

var Synapse = React.createClass({
  mixins: [ Router.State ],
  render: function () {
    var name = this.getPath();
    return (<div>
          <p>
            Welcome to Synapse, a very simple wiki.
            

            You can create and link to new notes by using the # symbol. Here's an #example.
            click on the #example link.

            try making a link to a new note!

            You can group and categorise by creating notes full of links based on subject. 
            For example, you can make a note called #projects, and then store links to different projects in there.

            Click on index to see a list of all the notes you've made.

            synapse is a minimal, 'directed acyclic graph', holarchic wiki. The idea for it came when I got frustrated with other
            note-taking programs being too opinionated on how I should write and organise my thoughts. What I really wanted was to make
            a 'little internet' of my ideas and projects, where anything could link to anything else, so that's what synapse is. 

            Please give me any feedback you have at @basiclaser on twitter or github, or hello@synapse.io
            
          </p>
        </div>
    );
  }
});

module.exports = Synapse; 
