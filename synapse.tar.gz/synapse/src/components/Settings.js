"use strict";

var React = require('react');
var Router = require('react-router');

var Settings = React.createClass({
  mixins: [ Router.State ],
  render: function () {
    var name = this.getPath();
    return (
        <div>
          <span>{name}</span>
          <p>Welcome to settings</p>
          <ul>
            <li>background color:</li>
            <li>text color:</li>
            <li>link color:</li>
            <li>font-size:</li>
          </ul>
        </div>
    );
  }
});

module.exports = Settings; 
