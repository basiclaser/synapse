'use strict';

var React = require('react/addons');


require('styles/Nav.scss');

var Nav = React.createClass({
  render: function () {
    return (
        <div>
          <span>{this.props.note.name} / index / notes that link to here</span>
        </div>
      );
  }
});

module.exports = Nav; 

